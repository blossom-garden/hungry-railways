advancement revoke @s only unbreakables:item_changed

item modify entity TisKodie weapon.mainhand unbreakables:make_unbreakable
item modify entity TisKodie weapon.offhand unbreakables:make_unbreakable

item modify entity TisKodie hotbar.0 unbreakables:make_unbreakable
item modify entity TisKodie hotbar.1 unbreakables:make_unbreakable
item modify entity TisKodie hotbar.2 unbreakables:make_unbreakable
item modify entity TisKodie hotbar.3 unbreakables:make_unbreakable
item modify entity TisKodie hotbar.4 unbreakables:make_unbreakable
item modify entity TisKodie hotbar.5 unbreakables:make_unbreakable
item modify entity TisKodie hotbar.6 unbreakables:make_unbreakable
item modify entity TisKodie hotbar.7 unbreakables:make_unbreakable
item modify entity TisKodie hotbar.8 unbreakables:make_unbreakable

item modify entity TisKodie inventory.0 unbreakables:make_unbreakable
item modify entity TisKodie inventory.1 unbreakables:make_unbreakable
item modify entity TisKodie inventory.2 unbreakables:make_unbreakable
item modify entity TisKodie inventory.3 unbreakables:make_unbreakable
item modify entity TisKodie inventory.4 unbreakables:make_unbreakable
item modify entity TisKodie inventory.5 unbreakables:make_unbreakable
item modify entity TisKodie inventory.6 unbreakables:make_unbreakable
item modify entity TisKodie inventory.7 unbreakables:make_unbreakable
item modify entity TisKodie inventory.8 unbreakables:make_unbreakable
item modify entity TisKodie inventory.9 unbreakables:make_unbreakable
item modify entity TisKodie inventory.10 unbreakables:make_unbreakable
item modify entity TisKodie inventory.11 unbreakables:make_unbreakable
item modify entity TisKodie inventory.12 unbreakables:make_unbreakable
item modify entity TisKodie inventory.13 unbreakables:make_unbreakable
item modify entity TisKodie inventory.14 unbreakables:make_unbreakable
item modify entity TisKodie inventory.15 unbreakables:make_unbreakable
item modify entity TisKodie inventory.16 unbreakables:make_unbreakable
item modify entity TisKodie inventory.17 unbreakables:make_unbreakable
item modify entity TisKodie inventory.18 unbreakables:make_unbreakable
item modify entity TisKodie inventory.19 unbreakables:make_unbreakable
item modify entity TisKodie inventory.20 unbreakables:make_unbreakable
item modify entity TisKodie inventory.21 unbreakables:make_unbreakable
item modify entity TisKodie inventory.22 unbreakables:make_unbreakable
item modify entity TisKodie inventory.23 unbreakables:make_unbreakable
item modify entity TisKodie inventory.24 unbreakables:make_unbreakable
item modify entity TisKodie inventory.25 unbreakables:make_unbreakable
item modify entity TisKodie inventory.26 unbreakables:make_unbreakable

item modify entity TisKodie armor.feet unbreakables:make_unbreakable
item modify entity TisKodie armor.legs unbreakables:make_unbreakable
item modify entity TisKodie armor.chest unbreakables:make_unbreakable
item modify entity TisKodie armor.head unbreakables:make_unbreakable
